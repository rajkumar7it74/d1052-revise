<?php

namespace Drupal\custom_event_subscriber\EventSubscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Drupal\user\UserEvents;
use Drupal\user\Event\UserEvent;
use GuzzleHttp\ClientInterface;
use Drupal\Core\Config\ConfigFactoryInterface;

class UserRegistrationSubscriber implements EventSubscriberInterface {

  protected $httpClient;
  protected $configFactory;

  public function __construct(ClientInterface $http_client, ConfigFactoryInterface $config_factory) {
    $this->httpClient = $http_client;
    $this->configFactory = $config_factory;
  }

  public static function getSubscribedEvents() {
    return [UserEvents::INSERT => 'onUserInsert'];
  }

  public function onUserInsert(UserEvent $event) {
    $user = $event->getUser();
    $config = $this->configFactory->get('custom_event_subscriber.settings');
    $endpoint = $config->get('crm_endpoint');
    $api_key = $config->get('crm_api_key');

    if ($endpoint && $api_key) {
      try {
        $this->httpClient->post($endpoint, [
          'headers' => ['Authorization' => 'Bearer ' . $api_key],
          'json' => [
            'name' => $user->getDisplayName(),
            'email' => $user->getEmail(),
          ],
        ]);
      } catch (\Exception $e) {
        \Drupal::logger('custom_event_subscriber')->error('CRM integration failed: ' . $e->getMessage());
      }
    }
  }
}
