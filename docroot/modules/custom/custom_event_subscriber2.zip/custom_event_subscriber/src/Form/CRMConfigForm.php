<?php

namespace Drupal\custom_event_subscriber\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

class CRMConfigForm extends ConfigFormBase {

  protected function getEditableConfigNames() {
    return ['custom_event_subscriber.settings'];
  }

  public function getFormId() {
    return 'crm_config_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('custom_event_subscriber.settings');

    $form['crm_endpoint'] = [
      '#type' => 'textfield',
      '#title' => $this->t('CRM Endpoint URL'),
      '#default_value' => $config->get('crm_endpoint'),
      '#required' => TRUE,
    ];

    $form['crm_api_key'] = [
      '#type' => 'textfield',
      '#title' => $this->t('CRM API Key'),
      '#default_value' => $config->get('crm_api_key'),
      '#required' => TRUE,
    ];

    return parent::buildForm($form, $form_state);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('custom_event_subscriber.settings')
      ->set('crm_endpoint', $form_state->getValue('crm_endpoint'))
      ->set('crm_api_key', $form_state->getValue('crm_api_key'))
      ->save();

    parent::submitForm($form, $form_state);
  }
}
