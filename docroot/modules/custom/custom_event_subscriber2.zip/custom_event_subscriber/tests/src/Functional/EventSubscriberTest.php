<?php

namespace Drupal\Tests\custom_event_subscriber\Functional;

use Drupal\Tests\BrowserTestBase;

/**
 * Tests the Custom Event Subscriber module.
 *
 * @group custom_event_subscriber
 */
class EventSubscriberTest extends BrowserTestBase {

  protected $defaultTheme = 'stark';

  protected static $modules = ['custom_event_subscriber', 'user'];

  public function testModuleEnabled() {
    $this->assertTrue(\Drupal::moduleHandler()->moduleExists('custom_event_subscriber'), 'Module is enabled.');
  }

  public function testCRMConfigFormAccessible() {
    $this->drupalLogin($this->drupalCreateUser(['administer site configuration']));
    $this->drupalGet('admin/config/custom-event-subscriber');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('CRM Endpoint URL');
  }
}
