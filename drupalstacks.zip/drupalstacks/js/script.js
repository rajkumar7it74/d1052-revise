document.addEventListener('DOMContentLoaded', () => {
    console.log('Bootstrap theme loaded!');
  });
  